package com.quantum.survey.service.impl;

public class PaperUserRelationShipsServiceImpl {

}
