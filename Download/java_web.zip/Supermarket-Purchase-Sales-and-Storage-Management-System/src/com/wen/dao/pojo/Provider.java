package com.wen.dao.pojo;

public class Provider {
	private int pid;
	private String pname;
	private String pphone;
	private String paddress;
	private String plinkman;
	public int getPid() {
		return pid;
	}
	public void setPid(int pid) {
		this.pid = pid;
	}
	public String getPname() {
		return pname;
	}
	public void setPname(String pname) {
		this.pname = pname;
	}
	public String getPphone() {
		return pphone;
	}
	public void setPphone(String pphone) {
		this.pphone = pphone;
	}
	public String getPaddress() {
		return paddress;
	}
	public void setPaddress(String paddress) {
		this.paddress = paddress;
	}
	public String getPlinkman() {
		return plinkman;
	}
	public void setPlinkman(String plinkman) {
		this.plinkman = plinkman;
	}
	
}
