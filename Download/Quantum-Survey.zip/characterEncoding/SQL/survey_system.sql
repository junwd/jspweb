/*
 Navicat Premium Data Transfer

 Source Server         : 1
 Source Server Type    : MySQL
 Source Server Version : 50733
 Source Host           : localhost:3306
 Source Schema         : survey_system

 Target Server Type    : MySQL
 Target Server Version : 50733
 File Encoding         : 65001

 Date: 29/06/2022 17:09:15
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for papers
-- ----------------------------
DROP TABLE IF EXISTS `papers`;
CREATE TABLE `papers`  (
  `paperId` int(11) NOT NULL AUTO_INCREMENT,
  `userId` int(11) NULL DEFAULT NULL,
  `paperTitle` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `paperSummary` varchar(300) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `paperStartDate` datetime NULL DEFAULT NULL,
  `paperEndDate` datetime NULL DEFAULT NULL,
  `paperType` int(11) NULL DEFAULT NULL,
  `paperFilltimes` int(11) NULL DEFAULT NULL,
  `paperPeriod` int(11) NULL DEFAULT NULL,
  `paperCount` int(11) NULL DEFAULT NULL,
  PRIMARY KEY (`paperId`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 4 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of papers
-- ----------------------------
INSERT INTO `papers` VALUES (1, 1, 'Admin Paper', 'Paper Summary', '2022-06-29 18:00:00', '2022-06-29 16:45:40', 1, 10, 30, 0);
INSERT INTO `papers` VALUES (3, 1, '问卷调查测试', '问卷调查测试，测试数据库添加，测试题目点价', '2022-06-29 16:47:46', '2022-07-01 16:47:46', 2, 20, 2, 0);

-- ----------------------------
-- Table structure for questions
-- ----------------------------
DROP TABLE IF EXISTS `questions`;
CREATE TABLE `questions`  (
  `qstId` int(11) NOT NULL AUTO_INCREMENT,
  `paperId` int(11) NULL DEFAULT NULL,
  `qstType` int(11) NULL DEFAULT NULL,
  `qstTitle` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `qstOption` varchar(1000) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `qstAnswer` varchar(1000) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `cascade_single` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `QsTSetTime` datetime NULL DEFAULT NULL,
  PRIMARY KEY (`qstId`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 12 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of questions
-- ----------------------------
INSERT INTO `questions` VALUES (3, 3, 1, '测试', '1#2#3#4', '0&0&0&0', 'no', '2022-06-29 16:47:59');
INSERT INTO `questions` VALUES (4, 3, 5, '测试3', '1#3', '0&0&0&0&0&0&0', 'no', '2022-06-29 16:48:23');
INSERT INTO `questions` VALUES (5, 3, 4, '1+1', '', '0', 'no', '2022-06-29 16:48:31');
INSERT INTO `questions` VALUES (6, 3, 3, '测试文本点击', '', '', 'no', '2022-06-29 16:48:46');
INSERT INTO `questions` VALUES (7, 3, 2, '测试4', '1#2#3#4', '0&0&0&0', 'no', '2022-06-29 16:49:02');
INSERT INTO `questions` VALUES (8, 3, 1, '测试6', '去#去#我#我', '0&0&0&0', 'no', '2022-06-29 16:49:16');
INSERT INTO `questions` VALUES (9, 3, 6, '', '#', '0&0', 'no', '2022-06-29 16:50:32');
INSERT INTO `questions` VALUES (10, 3, 6, '', '#', '0&0', 'no', '2022-06-29 16:50:36');
INSERT INTO `questions` VALUES (11, 3, 6, '', '#', '0&0', 'no', '2022-06-29 16:50:38');

-- ----------------------------
-- Table structure for users
-- ----------------------------
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users`  (
  `userId` int(11) NOT NULL AUTO_INCREMENT,
  `userName` varchar(40) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `userPassword` varchar(40) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `userMail` varchar(40) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `userReg` datetime NULL DEFAULT NULL,
  `userRole` int(11) NULL DEFAULT NULL,
  PRIMARY KEY (`userId`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 2 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of users
-- ----------------------------
INSERT INTO `users` VALUES (1, 'admin', 'admin', 'admin@zju.edu.cn', '2020-05-03 17:56:12', 0);

SET FOREIGN_KEY_CHECKS = 1;
