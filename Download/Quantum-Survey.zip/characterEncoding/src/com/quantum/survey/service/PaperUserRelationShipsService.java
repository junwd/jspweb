package com.quantum.survey.service;

public interface PaperUserRelationShipsService {

}
